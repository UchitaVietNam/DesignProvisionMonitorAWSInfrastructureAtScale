import os
import logging

# Set up the logging configuration
logging.basicConfig(level=logging.INFO)

def lambda_handler(event, context):
    # Log an info message
    response = "{} from Lambda!".format(os.environ['greeting'])
    logging.info(response)
    return response
